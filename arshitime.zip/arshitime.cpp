/*this program gives the user the choice to choose a text file and sort it in any of the 5 sorting functions
the user can choose two sorting algorithm. then after the sorted function is timed and put in an column
a searching option is given which is the choice to see the first or last 50 words of sorted array. and option to
search for a word from the file. at the end of the program user has a choice to repeat program or quit
*/ 
#include <iostream>
#include <string>
#include <fstream>
#include <string.h>
#include <chrono>
#include<bits/stdc++.h>
#include <iomanip> // this is used for the setw when making the column
using namespace std::chrono;
	void selectionSort(std::string *list, int size);
	void  bubbleSort(std::string *list,  int size);
	void merge(std::string *list, int low, int mid, int size);
	void merge_sort(std::string *list, int low, int size);
	void  quickSort(std::string *list, int low, int size);
	int partition (std::string *list, int low , int size);
	void insertionSort(std::string *list, int size);
	
	int openfileSize(std::ifstream& in_file, std::string textname);
	void openfile(std::ifstream& in_file, std::string *list, std::string *copy,std::string textname, int size);
	
	std::string askName(std::string name);
	std::string  menuBook( std::string &textname);
	
	void menuAlgorithm(std::string *list, int size, std::string *copy);
	void userMenu(int choice, int size, std::string *list, std::string *copy);

	std::string cleanArray(std::string *list, int size ); 
	void copyArray(std::string *list, std::string *copy, int size);
	void print(std::string *list, int size);
	void searchFirstLast(std::string *list, int size);
	bool searchWord(std::string *list, int size);
int main()
{

	char choices;
	std::string name;
	std::string textname;

	std::cout << "would you like to start the program? Press 'Y' or 'N'"<<std::endl;
	std::cin>> choices;
	
	
  do{
  
     std::ifstream in_file;
	 askName(name);
	 menuBook( textname); // to get the name of the file which the user choose 
	int x = openfileSize(in_file, textname); //get size of file
    std::string *list = new std::string[x];
	std::string *copy = new std::string[x];
    openfile(in_file, list, copy,textname,x); // put each word into each index of an array
	menuAlgorithm(list, x, copy); //gives user two choices to choose from the sorting functions
  	searchFirstLast(list, x);// search first or last 50 words of array
	searchWord(list, x); // search a word from the file


 
std::cout<<"would you like to restart the program? Press 'Y' or 'N'"<<std::endl;
 std::cin>> choices;
  }// end of do
  while(choices=='Y'|| choices=='y');
  return 0;
  
}//end of main






//gives user options of which file to choose from and then return the textname
std::string menuBook(std::string &textname){

	int choice;
	std::string history;
	std::string life;
	std::string hotel;
	
	std::cout<<"Choose the following number of the books"<<std::endl;
	std::cout<<"#1 THE HISTORY OF THE CONQUEST OF MEXICO"<<std::endl;
	std::cout<<"#2 LIFE WITHOUT PRINCIPLE"<<std::endl;
	std::cout<<"#3 THE BLUE HOTEL"<<std::endl;
	std::cin>>choice;
	
	if(choice==1){
		textname = "HistoryofMexico.txt";
		history = "THE HISTORY OF THE CONQUEST OF MEXICO";
	}
	else if (choice==2){
		textname = "LifeWithoutPrinciple.txt";
		life= "LIFE WITHOUT PRINCIPLE";
	}
	else if(choice==3){
		textname = "TheBlueHotel.txt";
		hotel = "THE BLUE HOTEL";
	}
	switch(choice){
	
		case 1:
		{
			std::cout<<"you choose "<< history <<std::endl;		
		break;
		}
		case 2:
			std::cout<<"you choose "<< life <<std::endl;
		break;
		
		
		case 3:
			std::cout<<"you choose "<< hotel <<std::endl;
		break;
		
		
	}//end switch
	
	return textname;
}

//returns the size of the file thats being opened 
int openfileSize(std::ifstream &in_file,  std::string textname){
    std::string words;
    int size =0;
	
    in_file.open(textname);
    if (in_file.fail()){
        std::cout << "Could not open file."<<std::endl;
        return -1; 
    }//end if 
    while(in_file >> words){
		size++;
    }//end while
	
	 in_file.close();
	 
    return size;
}//end openfileSize
	
	

std::string askName(std::string name){
	// std::string name;
  std::cout << "What is your name? ";
  std::cin>>name;
  std::cout << "Hello, " << name << "!\n";
  
  return name;
}

//reads the file into the array 
void openfile(std::ifstream& in_file, std::string *list, std::string *copy, std::string textname, int size){
	int counter = 0;
	std::string words;
	
	in_file.open(textname);
    if (in_file.fail()){
        std::cout << "Could not open file."<<std::endl;
        
    }//end if 
	
    while(in_file >> words){
	
		list[counter]= words;
		copy[counter]= words;
		counter++;
		
    }//end while
	cleanArray(list, size);
	
	 in_file.close();
}
	

// cleans the array from punctuations 
std::string cleanArray(std::string *list, int size ){
// take out all punctuations 

	for (int i=0; i<size;i++){	
		for (int j=0;j<list[i].length(); j++){		
			if (isalpha(list[i][j])){ //keep all alphabets 
				continue;	
			} //if
			else 
				if (list[i][j]== '\''){ // for apostrophe. got this from stack overflow 
						continue; 
					}//if
					//else
			else 
				if (list[i][j]== '-'){ // for hyphens. got this from geeks for geeks 
						continue; 
				}//if
			//else
				else	list[i].erase(list[i].begin()+j); 
				
				j--;
		}//end j loop

	}// end i loop
	
}// end function

//gives user the choice to choose two of the sort function to use on the text file
void menuAlgorithm(std::string *list, int size, std::string *copy){
	
	int input = 0;
	int newSize = 0;
	newSize= size/2;
	

	int choice = 0;
	std::cout<<"Choose two of the five sorting algorithm in which you would like to use to sort the file"<<std::endl;
	std::cout<<"Your first choice"<<std::endl;
	
	std::cout<<"#1 Selection sort"<<std::endl;
	std::cout<<"#2 Bubble sort"<<std::endl;
	std::cout<<"#3 Insertion sort"<<std::endl;
	std::cout<<"#4 Merge sort"<<std::endl;
	std::cout<<"#5 Quicksort"<<std::endl;
	std::cin>>choice;
	userMenu(choice,size,list, copy);
	
	std::cout <<"What is your second choice of the sorting algorithm"<<std::endl;
	std::cout<<"#1 Selection sort"<<std::endl;
	std::cout<<"#2 Bubble sort"<<std::endl;
	std::cout<<"#3 Insertion sort"<<std::endl;
	std::cout<<"#4 Merge sort"<<std::endl;
	std::cout<<"#5 Quicksort"<<std::endl;
	std::cin>>choice;
	userMenu(choice,size, list, copy);

}
//sorts the array with the choice the user gave and times the sorting function and puts it into a column. the average and size of array is displayed allong with the time it took to sort the array
// this is done three times with each choice of sorting function
void userMenu(int choice,int size, std::string *list, std::string *copy){
	int newSize= size/2;
	auto total_duration=0;
	int average =0;
	double around;
	double avg;
	if(choice==1){
	std::cout<<"full dataset of selection sort"<<std::endl; // the full data of the file will be sorted
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl; //column is made
    std::cout << "Runtime: " << std::setw(10);
	
	for (int i =0; i<3; i++){
		copyArray(list,copy,size);// unsorts the array before its being sorted 
		auto start = high_resolution_clock::now();
		
		selectionSort(list,size); //sorts the array
		
		 auto stop = high_resolution_clock::now();
		 double duration = duration_cast<microseconds>(stop - start).count(); 
		around += duration;
		
          std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
		
		
	}//end for
	avg = around/3;
	std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	
		
		
	std::cout<<"half dataset of selection sort"<<std::endl; // half of the data will be sorted and timed
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	for (int i =0; i<3; i++){
		copyArray(list,copy,newSize);
		auto start = high_resolution_clock::now();
		
		selectionSort(list,newSize);
		
		auto stop = high_resolution_clock::now();
		 double duration = duration_cast<microseconds>(stop - start).count(); 
		 around += duration;
		
          std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
		
	}
	avg = around/3;
		
			std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	
	}
	else if (choice==2){
	
	std::cout<<"full dataset of bubble sort "<<std::endl;
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	for (int i =0; i<3; i++){
		copyArray(list,copy,size);
		auto start = high_resolution_clock::now();
		bubbleSort(list,size);
	
		auto stop = high_resolution_clock::now();
		 double duration = duration_cast<microseconds>(stop - start).count(); 
           std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
		around += duration;
		}
		avg = around/3;
	
			std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	
	std::cout<<"half dataset of bubble sort"<<std::endl;	
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	for (int i =0; i<3; i++){
		copyArray(list,copy,newSize);
		auto start = high_resolution_clock::now();
		bubbleSort(list,newSize);
	
		auto stop = high_resolution_clock::now();
		 double duration = duration_cast<microseconds>(stop - start).count(); 
          std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
		 around += duration;
		
	}
	avg = around/3;
	
		std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	
	}
	else if(choice==3){
	
	std::cout<<"full dataset of insertion sort"<<std::endl;
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	
	for (int i =0; i<3; i++){
	copyArray(list,copy,size);
	auto start = high_resolution_clock::now();
		insertionSort(list,size);
		auto stop = high_resolution_clock::now();
		double duration = duration_cast<microseconds>(stop - start).count(); 
	 around += duration;
		
		std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
	}
	
	avg = around/3;
	
		std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	
	std::cout<<"half dataset of insertion sort"<<std::endl;
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	for (int i =0; i<3; i++){
	copyArray(list,copy,newSize);
	auto start = high_resolution_clock::now();
	
	insertionSort(list,newSize);
	auto stop = high_resolution_clock::now();
		double duration = duration_cast<microseconds>(stop - start).count(); 
	
	around += duration;
	 std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
	}
	
	avg = around/3;
		std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	}
	else if(choice==4){
	
	std::cout<<"full dataset of merge sort"<<std::endl;
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	for (int i =0; i<3; i++){
	copyArray(list,copy,size);
	auto start = high_resolution_clock::now();
		merge_sort(list,0,size-1);
		
			auto stop = high_resolution_clock::now();
		double duration = duration_cast<microseconds>(stop - start).count(); 
		around += duration;
		
		
		 std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
	}
	avg = around/3;
	
		std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	
	std::cout<<"half dataset of merge sort"<<std::endl;
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	for (int i =0; i<3; i++){
	copyArray(list,copy,newSize);
	auto start = high_resolution_clock::now();
		merge_sort(list,0,newSize-1);
		
			auto stop = high_resolution_clock::now();
		double duration = duration_cast<microseconds>(stop - start).count(); 
		around += duration;
		
		
		 std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
	}
	avg = around/3;
	
		std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	}
	else if(choice==5){
	
	std::cout<<"full dataset of quick sort"<<std::endl;
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	for (int i =0; i<3; i++){
	copyArray(list,copy,size);
	auto start = high_resolution_clock::now();
		quickSort(list, 0, size-1);
		auto stop = high_resolution_clock::now();
		double duration = duration_cast<microseconds>(stop - start).count(); 
		around += duration;
		avg = around/3;
		 std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
	}//end for 
	
		std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	
	std::cout<<"half dataset of quick sort"<<std::endl;
	std::cout  << std::setw(36) << "First Pass" << std::setw(23) << "Second Pass" << std::setw(34) << "Third Pass" <<std::endl;
    std::cout << "Runtime: " << std::setw(10);
	for (int i =0; i<3; i++){
	copyArray(list,copy,newSize);
	auto start = high_resolution_clock::now();
		quickSort(list,0,newSize-1);
		
		auto stop = high_resolution_clock::now();
		double duration = duration_cast<microseconds>(stop - start).count(); 
		around += duration;
		avg = around/3;
		
		 std::cout << "Time taken: "<< "#"<< i+1 << " = " << std::setw(35*(i))<< duration << " microseconds" << std::endl;
	}

		std::cout<<"the size of the array is: "<<size<<std::endl;
	std::cout<<"Average time to run the sorting algorithm: " << avg <<std::endl;
	}//end if
	
	}
	
void copyArray(std::string *list, std::string *copy, int size){
	for(int i =0; i<size; i++){
		list[i]=copy[i];
	}
}
	
	
void bubbleSort(std::string *list,  int size){


  for (int i =0;i<size;i++){ //iteration 
    bool p=false; //used this method to see when to stop the program.
   
	
    for (int j=0;j<size-1;j++){ //will do the comparison 
        
          if (list[j]>list[j+1]){ //ordering the array from least to greatest
            p=true; // set the bool to true os that it doesnt stop the program when finish one round of iteration
        
		   swap(list[j],list[j+1]); //call swap 
        }//end of if
		 
    }//end of second loop
	
    if(p==false) // function breaks if the array is already sorted 
    { break;}
  }//end of first loop
    
}//end bubbleSort

void selectionSort(std::string *list, int size){
	int min;
	std::string temp;
	for (int i=0; i<size-1; i++){
		min = i;
		for (int j=i+1; j<size; j++){ // finding the min value of the array
			if (list[j]<list[min]){
				min = j;
			}
		}	//swap with min value and i 
			temp= list[i];
			list[i]= list[min];
			list[min]= temp;
	}
}

void insertionSort(std::string *list, int size){
		std::string key;   // key is the index in which values will be compared with.
		int j = 0;
	
		for (int i =1; i< size; i++){
			key = list[i];
			j = i ;
				while (j > 0 && list[j-1] > key){
					//list[j] = list[j-1];
					swap(list[j],list[j-1]);
					j--;
				}//end while
			list[j ] = key;
			
		}//end  i loop
}

void merge_sort(std::string *list, int low, int size){

	if (low == size){
		return;
	}
		if (low < size){
		int mid;
		mid= low + (size - low)/2;
		// Split the data into two half.
		merge_sort(list, low, mid);
		merge_sort(list, mid+1, size);
		merge(list, low, mid, size);
	}
}

void merge(std::string *list, int low, int mid, int size)
{ 
    int n1 = (mid - low) + 1;  //size for first half
    int n2 =  (size - mid); // size of second half
  std::string L[n1], R[n2]; // make two different array left and right side array
  

  
    // Copy data to temp arrays L[] and R[] 
    for (int i = 0; i < n1; i++) {
        L[i] = list[low + i]; 
	}
    for (int j = 0; j < n2; j++) {
        R[j] = list[mid + 1+ j]; }
  
    // Merge the temp arrays back into arr[l..r]
    int i = 0; // this is the index of the first subarray 
    int j = 0; // this is the index of the second subarray 
    int k = low; // this is the index of the merged subarray which will put both subarray together
    while (i < n1 && j < n2) 
    { 
        if (L[i] <= R[j]) 
        { 
			
            list[k] = L[i]; 
            i++; 
        } 
        else
        { 
			
            list[k] = R[j]; 
            j++; 
        } 
        k++; 
    } 
  
    // Copy the remaining elements of L[], if there 
      // are any 
    while (i < n1) 
    { 
		
        list[k] = L[i]; 
        i++; 
        k++; 
    } 
  
    // Copy the remaining elements of R[], if there 
      // are any 
    while (j < n2) 
    { 
		
        list[k] = R[j]; 
        j++; 
        k++; 
    } 
	
} 

int partition (std::string *list, int low, int size ){
	 
   std::string pivot = list[low];
   int i = low - 1;
   int j = size + 1;
   
   while (i < j)
   {
		i++; while (list[i] < pivot) { i++; }
		j--; while (list[j] > pivot) { j--; }
		if (i < j) { swap(list[i], list[j]);
			
			}//end if
		}//end while
  
     return j;
 }

void  quickSort(std::string *list, int low, int size){
	
if (low >= size) {return;}
    
        int P_index=partition(list,low,size);
             quickSort(list,low,P_index);
             quickSort(list,P_index+1,size);
    
}

void print(std::string *list, int size){
	for(int i=0; i<size;i++) {
		if(list[i] == " "){
			continue;
			}else if(list[i] == "the"){ // this is a way for me to take out the specific words from the array
				continue;

			}else if(list[i] == "an"){
				continue;

			}else if(list[i]=="a"){
				continue;
			}
			else {std::cout << list[i] << std::endl;
			
		}//else
		
	}//end for
}//end function 

void searchFirstLast(std::string *list, int size){ // search first or last 50 words
	int input;
	
	std::cout<<"Would you like to see the first 50 words or the last 50 words"<<std::endl;
	std::cout<<"Press #1 if you would like to see the first 50 words of the sorted file"<<std::endl;
	std::cout<<"Press #2 if you would like to see the last 50 words of the sorted file"<<std::endl;
	std::cin>>input;
	
	if(input==1){
		for (int i =0;i<50;i++){
			std::cout<<list[i]<<std::endl;
		}
	}//end if
	
	if(input==2){
		for (int j = size-1; j>= (size-50);j--){
			std::cout<<list[j]<<std::endl;
		}
	}

}

bool searchWord(std::string *list, int size){ // search for a specific word
std::string find="";
	std::cout<<"which word would you like to search from this file"<<std::endl;
	std::cin>>find;
	
	for (int i =0; i<size;i++){
		if (list[i]==find){
		std::cout<<"true"<<std::endl;
			return true;
		}
	}
	std::cout<<"false"<<std::endl;
	return false;
}